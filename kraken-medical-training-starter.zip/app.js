const menuButton = document.getElementById("menuButton");
const mainNav = document.getElementById("mainNav");
const courseSearch = document.getElementById("courseSearch");
const courseCards = [...document.querySelectorAll(".course-card")];
const emptyState = document.getElementById("emptyState");

menuButton.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
  });
});

courseSearch.addEventListener("input", (event) => {
  const query = event.target.value.trim().toLowerCase();
  let visibleCount = 0;

  courseCards.forEach((card) => {
    const content = `${card.dataset.search} ${card.textContent}`.toLowerCase();
    const matches = content.includes(query);
    card.hidden = !matches;
    if (matches) visibleCount += 1;
  });

  emptyState.hidden = visibleCount !== 0;
});

document.getElementById("year").textContent = new Date().getFullYear();
